#ifndef MESSAGE_H
#define MESSAGE_H
#include <iostream>
#include <string>
#include <QVector>
#include <QString>
using namespace std;
// struct Signal
typedef struct Signal{
    char* mux;
    char* name;
    int length;
    char by_order;
    char val_type;
    float factor;
    int offset;
    int min;
    int max;
    char* unit;
    char* syntax;
    char* comment;
}Signal;
// struct messaged_Signal
typedef struct messaged_Signal{
    int Sbit;
    Signal sig;
}messaged_Signal;
// struct message
typedef struct Messages{
    uint64_t ID;
    int DLC;
    char* name;
    char* syntax;
    QVector<messaged_Signal> list_Signal;
    char* type;
}Messages;
typedef struct  database{
    QVector<Messages> list_message;
    QVector<Signal> list_Signal;
}database;

#endif // MESSAGE_H
