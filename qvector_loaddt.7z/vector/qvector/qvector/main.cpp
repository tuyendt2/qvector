#include "mainwindow.h"
#include <QApplication>
#include "data_struct.h"
#include "load.h"
#include "mylib.h"
using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    ifstream in;
in.open("C:/Users/HCD-Fresher295/Desktop/a.dbc");
//    QVector<Messages*> rs =loadDatabaseM(in);
//for(int i=0;i<rs.size();i++){
//    cout<<rs.at(i)->name<<endl;
//}
if(in.is_open()){
    database rs = loadDatabase(in);
QVector<Messages> list_message = rs.list_message;
QVector<Signal> list_signal = rs.list_Signal;
for(int i=0;i<list_message.size();i++){
    cout<<list_message.at(i).name<<endl;
}
for(int i=0;i<list_signal.size();i++){
    cout<<list_signal.at(i).name<<endl;
}
}
in.close();
    return a.exec();
}
