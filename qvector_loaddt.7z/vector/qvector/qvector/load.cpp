#include "load.h"
// load database
database loadDatabase(ifstream &in){
 database rs;
 QVector<Messages> list_message;
 QVector<Signal> list_Signal;
 char str[1000];
 index_arr result ;
 int check=0;

 while(!in.eof()){
             // if check==1 , pass away the block
             if(check==0)
             {
             in.getline(str,1000);
             cout<<"str = "<<str<<endl;
             result = split(str);
            for(int i=0;i<result.index;i++){
                cout<<result.arr[i]<<endl;
             }
             }
             if((result.index>0)){
             if(compare_arr(result.arr[0],(char *)"BO_")){
                 cout<<"right message !"<<endl;
                Messages mess =load_Message(result);
                cout<<"right message 2 !"<<endl;
                 // create a qvector for saving all Signals of above message
                 QVector<messaged_Signal> sgn_list;
                 // read the next line to keep on processing
                 in.getline(str,1000);
                 result = split(str);
                 //set check=1 so the program will not read the next line in the following loop
                 check=1;
                 cout<<"ddasd"<<endl;
                 if((result.index>0))
                    {
                     while(compare_arr(result.arr[0],(char *)"SG_"))
                         {
                             // create a new Signal
                         messaged_Signal mess_sig =load_Signal(result);
                             cout<<"cccc"<<endl;
                          //  cout<<"name :"<<mess_sig->sig->name<<endl;
                             // add above Signal to Signal list of messaged Signal
                             sgn_list.append(mess_sig);
                              //  mess->list_Signal.append(mess_sig);
                             cout<<"aaaa"<<endl;
                             // add Signal list
                             Signal sig = mess_sig.sig;
                             if(!check_item_exist(list_Signal,sig)){ list_Signal.append(sig);
                             cout<<"size : "<<list_Signal.size()<<endl;
                             }
                             // read the next line
                             in.getline(str,1000);
                             cout<<"str=: "<<str<<endl;
                             result = split(str);
                             if(result.index==0) break;
                         }
                    }
                 cout<<sgn_list.size()<<endl;
                     if(sgn_list.size())
                     {
                         cout<<"asasda"<<endl;
                        // mess->list_Signal=QVector<messaged_Signal>(sgn_list.size());
                        cout<<"list size : "<< mess.list_Signal.size()<<endl;

                     }else{
                     // do nothing
                     }
                     list_message.append(mess);
             }
             }
             else {check=0;}
 }
 rs.list_message=list_message;
 rs.list_Signal=list_Signal;
 return rs;
}
QVector<Messages> loadDatabaseM(ifstream &in){
 QVector<Messages> list_message;
 char str[1000];
 index_arr result ;
 while(!in.eof()){
             in.getline(str,1000);
             cout<<str<<endl;
             result = split(str);
             if((result.index>0)){
             if(compare_arr(result.arr[0],(char *)"BO_")){
                 Messages mess=load_Message(result);
                 //cout<<mess<<endl;
                //cout<<mess->name.c_str()<<endl;
                list_message.append(mess);
                cout<<"size= : "<<list_message.size()<<endl;
             }
             }
 }
 return list_message;
}

// so sanh Signal
bool compare_Signal(Signal  sig1,Signal sig2){
    if(strcmp(sig1.name,sig2.name)) return false;
    if(sig1.length!=sig2.length) return false;
    if(sig1.by_order!=sig2.by_order) return false;
    if(sig1.val_type!=sig2.val_type) return false;
    if(sig1.offset!=sig2.offset) return false;
    if(sig1.factor!=sig2.factor) return false;
    cout<<"Signal da ton tai !"<<endl;
    return true;
}

// load messaged Signal
messaged_Signal  load_Signal(index_arr data){

    messaged_Signal mess_Signal;
    if(compare_arr( data.arr[0],(char*)"SG_")){
    mess_Signal.sig.name=(char*)malloc(sizeof(char));
    strcpy(mess_Signal.sig.name,data.arr[1]);
    cout<<mess_Signal.sig.name<<endl;
    mess_Signal.Sbit=atoi(data.arr[2]);
    mess_Signal.sig.length=atoi(data.arr[3]);
    mess_Signal.sig.by_order=data.arr[4][0];
    mess_Signal.sig.val_type=data.arr[4][1];
    mess_Signal.sig.factor=atof(data.arr[5]);
    mess_Signal.sig.min=atoi(data.arr[7]);
    mess_Signal.sig.max=atoi(data.arr[8]);
    mess_Signal.sig.offset=atoi(data.arr[6]);
    mess_Signal.sig.unit= (char*)malloc(sizeof(char));
    mess_Signal.sig.syntax=(char*)malloc(sizeof(char));
    if(data.index==10){
    strcpy(mess_Signal.sig.unit,"");
    strcpy(mess_Signal.sig.syntax,data.arr[9]);
    }else{
        strcpy(mess_Signal.sig.unit,data.arr[9]);
        strcpy(mess_Signal.sig.syntax,data.arr[10]);
    }
    }
    cout<<"done load signal"<<endl;
    return mess_Signal;
}
// load message
Messages load_Message(index_arr data){
    Messages msg;
   // cout<<msg<<endl;
    if(compare_arr( data.arr[0],(char*)"BO_")){
        msg.name=(char*)malloc(sizeof(char));
        msg.ID= atol(data.arr[1]);
        strcpy(msg.name ,data.arr[2]);
        cout<<msg.name<<endl;
        msg.DLC=atoi(data.arr[3]);
        msg.syntax=(char*)malloc(sizeof(char));
        strcpy(msg.syntax,data.arr[4]);
        cout<<msg.syntax<<endl;
        msg.type=(char*)malloc(sizeof(char));
    if(msg.ID>>7!=0){
        strcpy(msg.type,"Extended");
    }else{
         strcpy(msg.type,"Standard");
    }
    }
cout<<"done"<<endl;
    return msg;
}
bool check_item_exist(QVector<Signal> list_Signal,Signal sig){
for(int i=0;i<list_Signal.size();i++){
    if(compare_Signal(list_Signal.at(i),sig)) return true;
}
return false;
}
