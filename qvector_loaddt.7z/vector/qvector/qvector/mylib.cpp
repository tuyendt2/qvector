#include "mylib.h"
#include "malloc.h"
#include "cstring"
#include "string.h"
using namespace std;

extern bool compare_arr(char *str_1 , char *str_2)
{
    if(strlen(str_1)==strlen(str_2)){
        for(unsigned int i=0;i<strlen(str_1);i++){
        if(str_1[i]!=str_2[i]) return false;
        }
        cout<<"true"<<endl;
        return true;
    }
    else{
    return false;
    }

}
index_arr split(char str[])
{
        int index = 0;
        //int i;
        char **b = (char **)malloc(100*sizeof(char));
        char *p;
        p = strtok(str, "|,[]()\"@: "); //cat chuoi bang cac ky tu ,. va space
        while(p != NULL)
        {
                b[index] = p;
                index++;
                p = strtok(NULL, "|,[]()\"@: "); //cat chuoi tu vi tri dung lai truoc do
        }
        for(int i=0; i<index;i++){

        }
       index_arr result;
       result.arr=b;
       result.index=index;
        return result ;
}
