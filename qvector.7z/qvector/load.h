#ifndef LOAD_H
#define LOAD_H
#include <iostream>
#include <fstream>
#include "mylib.h"
#include "data_struct.h"
#include  <QVector>
using namespace std;
// struct store message and Signal
// load database
database loadDatabase(ifstream &in);
QVector<Messages *> loadDatabaseM(ifstream &in);
bool compare_Signal(Signal * sig1,Signal * sig2);
messaged_Signal * load_Signal(index_arr data);
Messages *load_Message(index_arr data);
bool check_item_exist(QVector<Signal*> list_Signal,Signal *sig);
#endif // LOAD_H
