#ifndef MYLIB_H
#define MYLIB_H
#include "stdlib.h"
#include <iostream>
using namespace std;

typedef struct index_arr{
    char ** arr;
    int index;
} index_arr ;
extern bool compare_arr(char *a,char *b);
extern index_arr split(char str[]);
#endif // MYLIB_H
