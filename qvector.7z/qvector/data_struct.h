#ifndef MESSAGE_H
#define MESSAGE_H
#include <iostream>
#include <string>
#include <QVector>
#include <QString>
using namespace std;
// struct Signal
typedef struct Signal{
    string mux;
    string name;
    int length;
    char by_order;
    char val_type;
    float factor;
    int offset;
    int min;
    int max;
    string unit;
    string syntax;
    string comment;
}Signal;
// struct messaged_Signal
typedef struct messaged_Signal{
    int Sbit;
    Signal *sig;
}messaged_Signal;
// struct message
typedef struct Messages{
    uint64_t ID;
    int DLC;
    string name;
    string syntax;
    QVector<messaged_Signal*> list_Signal;
    string type;
}Messages;
typedef struct  database{
    QVector<Messages*> list_message;
    QVector<Signal*> list_Signal;
}database;

#endif // MESSAGE_H
